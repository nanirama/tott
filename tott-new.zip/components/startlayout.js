import { React, useState, Fragment } from "react";


const StartLayout =  ({ children }) => {

return (

<>
{children}
</>

)
}

export default StartLayout