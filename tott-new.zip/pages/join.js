import Layout from "../components/layout"
import JoinIndex from "../components/Join"

export default function Join() {
  return (
    <JoinIndex/>
  )
}