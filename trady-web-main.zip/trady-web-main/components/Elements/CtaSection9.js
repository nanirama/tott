import Link from "next/link";
import Button from "../../components/Button/index"
export default function CtaSection9() {

    return (
        <div className="bg-gray-50 lg:py-24 py-16">
            {/* <div className="max-w-3xl mx-auto justify-center items-center text-center px-4">
                <h2 className="md:text-4xl text-3xl font-semibold text-gray-900 md:tracking-tight mb-5">Start your free trial</h2>
                <p className="md:text-xl text-lg font-normal text-gray-500 md:mb-10 mb-8">Be the first to know about releases and industry news and insights.</p>
                <div className="flex md:flex-row flex-col items-stretch max-w-md mx-auto">
                </div>
                <div className="flex md:flex-row flex-col text-center justify-center w-full">
                    <Link href="/"><a className="inline-block text-center rounded-lg bg-white border border-slate-300 py-3 px-5 text-gray-600 text-base font-medium md:mr-3 md:mb-0 mb-3 md:w-auto w-full">Learn More</a></Link>
                    <Button />
                </div>
            </div> */}
        </div>
    )

}